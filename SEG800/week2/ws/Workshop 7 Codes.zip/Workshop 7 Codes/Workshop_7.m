
%% Project 2.2
%Part (a & b)
clear all

f = imread('girl.tif');
vOrigin = pixVal4e(f,1,1);
[M,N] = size(f);
vMid = pixVal4e(f,floor(M/2)+1,floor(N/2)+1);
disp(vOrigin)
disp(vMid)

%% Project 2.2
%Part (c)
disp('Part (c)')
f = imread('girl.tif');
[r, c, v] = cursorValues4e(f);


fprintf('You clicked on: Row = %d, Column = %d\n', r, c);

fprintf('Pixel value at that point: %d\n', v);

%% Project 2.5
disp('Part b');
f = imread('rose1024.tif');

[M, N] = size(f); % M = number of rows, N = number of columns
side = round(min(M, N) / 2); % Ensures square fits within both dimensions
rUL = round((M - side) / 2); % Upper-left row
cUL = round((N - side) / 2); % Upper-left column
rLR = rUL + side - 1; % Lower-right row
cLR = cUL + side - 1; % Lower-right column
mask = mask4e(M, N, rUL, cUL, rLR, cLR);
figure, imshow(mask);
title('Centered Square Mask');

%%
disp('Part c');

numOnes = sum(mask(:)); 
expected = (rLR - rUL + 1) * (cLR - cUL + 1);
fprintf('Number of 1s in mask: %d\n', numOnes);

fprintf('Expected number of 1s: %d\n', expected);

if numOnes == expected
disp('✅ The mask has the correct number of 1s.');


else
disp('✅ There is a mismatch in the mask.');
end
%%
disp('Part d');
f = imread('rose1024.tif');
[M, N] = size(f);
side = round(min(M, N) / 2);
rUL = round((M - side) / 2);
cUL = round((N - side) / 2);
rLR = rUL + side - 1;
cLR = cUL + side - 1;
mask = mask4e(M, N, rUL, cUL, rLR, cLR);
fDouble = double(f);
maskedImage = uint8(fDouble .* mask);
figure, imshow(f); title('Original Image');
figure, imshow(maskedImage); title('Masked Image (Center Region Only)');





%% Functions Workshop 7

function v = pixVal4e(f,r,c)
v = f(r,c);
end

function [r, c, v] = cursorValues4e(f)
figure, imshow(f); 
[c, r] = ginput(1); % Get one point: x = c, y = r
r = round(r); % values to nearest pixel
c = round(c);
p = gcf; 
close(p); % Close the window
v = pixVal4e(f, r, c); 
end

function m = mask4e(M, N, rUL, cUL, rLR, cLR)
m = zeros(M, N); 
if rUL < 1 || cUL < 1 || rLR > M || cLR > N
error('Rectangle exceeds mask boundaries');
end
% Step 3: Fill the rectangle area with 1s


m(rUL:rLR, cUL:cLR) = 1;
end